import matplotlib
import matplotlib.pyplot as plt
import scipy
from scipy import special
import numpy as np

#Custom module
import ber

def main():
    print("\nDynamic attribute are with key and value pair: create an object with attributes as: ")
    print("\nFor BPSK:ber.Ber(dig_mod='bpsk'), QPSK: ber.Ber(dig_mod='qpsk'),\nMPSK: ber.Ber(dig_mod='mpsk',lvl=number), MQAM: ber.Ber(dig_mod='mqam',lvl=number)\n\n")
    print("Press Enter to continue.")
    input()
    # For BPSK
    mod_eror_bpsk=ber.Ber(dig_mod='mqam', lvl=int(8))
    cal_ber=mod_eror_bpsk.Q_lower_n()
    cal_ber=mod_eror_bpsk.Q_fun()
    snr,ber1=mod_eror_bpsk.Q_fun_result()
    plt.semilogy(snr,ber1)
    plt.show()
if __name__ == "__main__":
    main()