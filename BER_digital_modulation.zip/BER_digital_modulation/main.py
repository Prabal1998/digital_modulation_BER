import matplotlib
import matplotlib.pyplot as plt
import scipy
from scipy import special
import numpy as np
import os

#Custom module
import ber

def main():
    print("\nDynamic attribute are with key and value pair: create an object with attributes as: ")
    print("\nFor BPSK:ber.Ber(dig_mod='bpsk'), QPSK: ber.Ber(dig_mod='qpsk'),\nMPSK: ber.Ber(dig_mod='mpsk',lvl=number), MQAM: ber.Ber(dig_mod='mqam',lvl=number)\n\n")
    print("Press Enter to continue.")
    input()
    # For BPSK
    mod_eror_bpsk=ber.Ber(dig_mod='bpsk')
    cal_ber=mod_eror_bpsk.Q_lower_n()
    cal_ber=mod_eror_bpsk.Q_fun()
    snr,ber1=mod_eror_bpsk.Q_fun_result()

    # For QPSK
    mod_eror_qpsk=ber.Ber(dig_mod='qpsk')
    cal_ber=mod_eror_qpsk.Q_lower_n()
    cal_ber=mod_eror_qpsk.Q_fun()
    snr,ber2=mod_eror_qpsk.Q_fun_result()

    # For MPSK, M-level: 4
    mod_eror_mpsk4=ber.Ber(dig_mod='mpsk',lvl=int(4))
    cal_ber=mod_eror_mpsk4.Q_lower_n()
    cal_ber=mod_eror_mpsk4.Q_fun()
    snr,ber3=mod_eror_mpsk4.Q_fun_result()


    # For MPSK, M-level: 8
    mod_eror_mpsk8=ber.Ber(dig_mod='mpsk',lvl=int(8))
    cal_ber=mod_eror_mpsk8.Q_lower_n()
    cal_ber=mod_eror_mpsk8.Q_fun()
    snr,ber4=mod_eror_mpsk8.Q_fun_result()

    # For MPSK, M-level: 16
    mod_eror_mpsk16=ber.Ber(dig_mod='mpsk',lvl=int(16))
    cal_ber=mod_eror_mpsk16.Q_lower_n()
    cal_ber=mod_eror_mpsk16.Q_fun()
    snr,ber5=mod_eror_mpsk16.Q_fun_result()


    # For qam, M-level: 4
    mod_eror_qam4=ber.Ber(dig_mod='mqam',lvl=int(4))
    cal_ber=mod_eror_qam4.Q_lower_n()
    cal_ber=mod_eror_qam4.Q_fun()
    snr,ber6=mod_eror_qam4.Q_fun_result()


    # For qam, M-level: 8
    mod_eror_qam8=ber.Ber(dig_mod='mqam',lvl=int(8))
    cal_ber=mod_eror_qam8.Q_lower_n()
    cal_ber=mod_eror_qam8.Q_fun()
    snr,ber7=mod_eror_qam8.Q_fun_result()

    # For qam, M-level: 16
    mod_eror_qam16=ber.Ber(dig_mod='mqam',lvl=int(16))
    cal_ber=mod_eror_qam16.Q_lower_n()
    cal_ber=mod_eror_qam16.Q_fun()
    snr,ber8=mod_eror_qam16.Q_fun_result()

    #plt.semilogy(snr,ber1,label='BPSK',color='blue')
    #plt.semilogy(snr,ber2,label='QPSK,BPSK',color='green')
    #plt.semilogy(snr,ber3,label='MPSK-4',color='red')
    #plt.semilogy(snr,ber4,label='MPSK-8',color='orange')
    #plt.semilogy(snr,ber5,label='MPSK-16',color='magenta')
    plt.semilogy(snr,ber6,label='QAM-4 MPSK-4',color='yellow')
    plt.semilogy(snr,ber7,label='QAM-8',color='black')
    plt.semilogy(snr,ber8,label='QAM-16',color='violet')

    ###Grid wouldn't show up if snr array is very large
    plt.grid(True, which='both', linestyle='--', linewidth=0.5,color='green')
    plt.xlabel(r'$\frac{E_b}{N_0} \, (\mathrm{dB})$',fontsize=16)
    plt.ylabel('BER',fontsize=16)
    plt.title('BER comparison of different modulation schemes')
    plt.legend()
    plt.tight_layout()

    #save to specific location
    #current directory
    curr_directory=os.getcwd()
    next_dir=input('Enter the directory to store graph: ')
    os.chdir(next_dir)
    #save
    fil_name=input('Enter file name: ')
    plt.savefig(fil_name,format='svg',transparent=True)

    #return back
    os.chdir(curr_directory)

    plt.show()

    





if __name__ == "__main__":
    main()
        




