import scipy
import scipy.integrate as integrate
import numpy as np
import math

class Ber:
    def __init__(self,**kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

        self.snr_db=np.arange(-10,12,0.1)
        #conversion from dB to decimal using exponent
        self.snr=10**(self.snr_db/10)

    def Q_lower_n(self):
        self.lower_limit=np.array([],dtype=np.float64)
        
        if self.dig_mod == 'bpsk':
            for x in range(0,len(self.snr)):
                self.lower_limit_temp= (np.sqrt(2*self.snr[x]))
                self.lower_limit=np.append(self.lower_limit,self.lower_limit_temp)
        
        elif self.dig_mod == 'qpsk':
            for x in range(0,len(self.snr)):
                self.lower_limit_temp=np.sqrt(2*self.snr)
                self.lower_limit=np.append(self.lower_limit,self.lower_limit_temp)
        
        elif self.dig_mod == 'mpsk':
            for x in range(0,len(self.snr)):
                self.lower_limit_temp=(np.sqrt(2*self.snr*np.log2(self.lvl))*np.sin(np.pi/self.lvl))
                self.lower_limit=np.append(self.lower_limit,self.lower_limit_temp)
        
        elif self.dig_mod=='mqam':
            for x in range(0,len(self.snr)):
                self.lower_limit_temp=np.sqrt((3*self.snr*np.log2(self.lvl))/(self.lvl-1))
                self.lower_limit=np.append(self.lower_limit,self.lower_limit_temp)
        else:
            print('Analysis is possible for BPSK,QPSK,MPSK and MQAM. Enter positive integer level for M-array signalings: ')

    def Q_fun(self):
        self.Q_fun_arr=np.array([],dtype=np.float64)
        for x in range(0,len(self.snr)):
            def Q_fun_int(k):
                return (1/np.sqrt(2*np.pi))*np.exp(-0.5*k**2)
            self.Q_fun=integrate.quad(Q_fun_int,self.lower_limit[x],np.inf)
            self.Q_fun_arr=np.append(self.Q_fun_arr,self.Q_fun[0])
        
    
    def Q_fun_result(self):

        if self.dig_mod == 'bpsk':
            self.Q_fun_ber=self.Q_fun_arr
        elif self.dig_mod=='qpsk':
            self.Q_fun_ber=self.Q_fun_arr
        elif self.dig_mod== 'mpsk':
            self.Q_fun_ber=(2*self.Q_fun_arr)/np.log2(self.lvl) 
        elif self.dig_mod=='mqam':
            self.Q_fun_ber=(4*self.Q_fun_arr)/np.log2(self.lvl)
        else:
            print('Error somewhere ')
        return self.snr_db, self.Q_fun_ber


        




        
